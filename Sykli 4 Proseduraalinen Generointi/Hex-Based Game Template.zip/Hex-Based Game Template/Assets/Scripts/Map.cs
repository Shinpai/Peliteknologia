﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map : MonoBehaviour {

	public GameObject hexPrefab;

	// Size of map in terms of number of hexes
	int width = 64;
	int height = 40;

	float xOffset = 0.9f;
	float zOffset = 0.78f;

    // Use this for initialization
    void Start () {
        for (int x = 0; x < width; x++) {
			for (int z = 0; z < height; z++) {

				float xPos = x * xOffset;

				// Are we on an odd row?
				if (z % 2 == 1) {
					xPos += xOffset/2f;
				}
					
				GameObject hex_go = (GameObject)Instantiate (hexPrefab, new Vector3(xPos, 0 , z * zOffset), Quaternion.identity );

				// Name the hex -gameobjects. Index 0,0 is at lower left corner.
				hex_go.name = "Hex_" + x + "_" + z;                
				hex_go.transform.SetParent (this.transform);

                // haeejuut tehdään muutokset heksan väriin parilla eri tavalla
                // Color hexcolor = AssignRandomColor();
                Color hexcolor = AssignLogicalColor(hex_go.name);

                // itse muutos värin generoinnin jälkeen
                MeshRenderer mr = hex_go.GetComponentInChildren<MeshRenderer>();
                mr.material.color = hexcolor;                
			}
		}
	}

    /// <summary>
    /// Napataan heksan koordinaatista tietoa ja sen perusteella väri
    /// </summary>
    /// <param name="hexname"></param>
    /// <returns></returns>
    private Color AssignLogicalColor(string hexname)
    {
        string[] split = hexname.Split('_');
        Debug.Log(split[0] + " " + split[1] + " " + split[2]);
        int x = int.Parse(split[1]);
        int y = int.Parse(split[2]);
        // ehtoja vaihtamalla/randomisoimalla voi tästä helposti saada eri kuvioita
        if (15 < x && x < 25)
            return Color.blue;
        if (15 < y && y < 25)
            return Color.blue;
        return Color.white;
    }

    /// <summary>
    /// Napataan random arvo ja sen perusteella väri
    /// Random.Range toteuttaa normaalijakauman
    /// </summary>
    /// <returns></returns>
    private Color AssignRandomColor()
    {
        float r = UnityEngine.Random.Range(0, 1.0f);
        if (r < .2f)
            return Color.black;
        if (r < .4f)
            return Color.gray;
        if (r < .6f)
            return Color.white;
        if (r < .8f)
            return Color.cyan;
        return Color.blue;
    }
}
