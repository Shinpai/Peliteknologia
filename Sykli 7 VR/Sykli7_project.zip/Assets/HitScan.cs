﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HitScan : MonoBehaviour
{
    bool noHat = true;
    float counter = 0;
    GameObject player, hat, RadialFill;
    Vector3 vanhapos;

    private void Start()
    {
        RadialFill = GameObject.Find("RadialFill");
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        RadialFill.GetComponent<Image>().fillAmount = counter;

        Vector3 fwd = transform.TransformDirection(Vector3.forward);
        RaycastHit hit;
        // raycast osuma kiinni
        if (Physics.Raycast(transform.position, fwd, out hit))
        {
            // Tähän eri tapaukset osumista
            switch (hit.collider.name)
            {
                // hajottaa kuution 
                case ("Cube"):
                    counter += .01f;
                    if (counter > 1)
                    {
                        Destroy(hit.collider.gameObject);
                    }
                    break;
                // telettää pelaajan kohteeseen
                case ("Teleport"):
                    counter += .01f;
                    if (counter > 1)
                    {                        
                        // 12 y-arvoksi ettei jää maan sisään
                        player.transform.position = new Vector3(hit.collider.gameObject.transform.position.x, 
                                                                12,
                                                                hit.collider.gameObject.transform.position.z);
                        // jos on hattu niin päivitetään mukana
                        if (!noHat)
                        {
                            hat.transform.position = player.transform.position;
                        }
                    }
                    break;
                // laittaa hatun päähän
                case ("BottomPart"):
                case ("TopPart"):
                    if (noHat)
                        counter += .01f;
                    if (counter > 1)
                    {
                        hat = hit.collider.transform.parent.gameObject;
                        vanhapos = hat.transform.position; // paikka talteen jos telettää välissä
                        hat.transform.position = player.transform.position;
                        noHat = false;
                    }
                    break;
                // laittaa hatun hyllyyn
                case ("Shelf"):
                    if (!noHat)
                        counter += .01f;
                    if (counter > 1)
                    {
                        hat.transform.position = vanhapos;
                        noHat = true;
                    }
                    break;
                default:
                    counter = 0;
                    break;
            }

        }
        Debug.Log(hit.collider.name);
        Debug.Log(counter);
    }
}
